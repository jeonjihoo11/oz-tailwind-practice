import img1 from "../images/img1.png";
import img2 from "../images/img2.png";
import img3 from "../images/img3.png";
import img4 from "../images/img4.png";
export const contents = [
  {
    id: 1,
    img: img1,
    title: "IT스타트업 | 사업개발 캠프",
    subtitle: "IT 창업에 꼭 필요한 지식만 배우고 100% 수익!",
  },
  {
    id: 2,
    img: img2,
    title: "IT스타트업 | 웹 개발 초격자 캠프",
    subtitle: "실력있는 웹 개발자로 확실하게 커리어 전환!",
  },
  {
    id: 3,
    img: img3,
    title: "관리형 부트캠프",
    subtitle: "웹 풀스택을 넘어 생성형 AI 까지!",
  },
  {
    id: 4,
    img: img4,
    title: "린스타트업 맞춤형 MVP 개발자 양성 과정!",
    subtitle: "린스타트업 맞춤형 Serverless MVP 개발!",
  },
  {
    id: 1,
    img: img1,
    title: "IT스타트업 | 사업개발 캠프",
    subtitle: "IT 창업에 꼭 필요한 지식만 배우고 100% 수익!",
  },
  {
    id: 2,
    img: img2,
    title: "IT스타트업 | 웹 개발 초격자 캠프",
    subtitle: "실력있는 웹 개발자로 확실하게 커리어 전환!",
  },
  {
    id: 3,
    img: img3,
    title: "관리형 부트캠프",
    subtitle: "웹 풀스택을 넘어 생성형 AI 까지!",
  },
  {
    id: 4,
    img: img4,
    title: "린스타트업 맞춤형 MVP 개발자 양성 과정!",
    subtitle: "린스타트업 맞춤형 Serverless MVP 개발!",
  },
];
